import { Helmet } from "react-helmet-async";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

const projects = [
  {
    title: "Employee Payroll System",
    desc: "A full-stack payroll management platform with authentication, employee CRUD, and payroll processing.",
    stack: ["React.js", "Next.js", "Express.js", "MongoDB"],
    demo: "#",
  },
  {
    title: "AI-Powered City Navigation System",
    desc: "Pathfinding using A* over real city graphs with analytics and visualization.",
    stack: ["Python", "A*", "NetworkX", "Matplotlib"],
    demo: "#",
  },
  {
    title: "Grocify – Online Grocery Store",
    desc: "A responsive e-commerce front-end with product catalog, cart, and JSON server API.",
    stack: ["React.js", "JavaScript", "JSON Server"],
    demo: "#",
  },
];

const Projects = () => {
  return (
    <>
      <Helmet>
        <title>Projects | Dinesh Borra</title>
        <meta name="description" content="Projects by Dinesh Borra: Employee Payroll System, AI City Navigation, and Grocify." />
        <link rel="canonical" href={typeof window !== 'undefined' ? window.location.href : '/projects'} />
      </Helmet>

      <section className="container py-12">
        <header className="mb-8 text-center">
          <h1 className="font-display text-3xl font-bold md:text-4xl">Projects</h1>
          <p className="mt-2 text-muted-foreground">Selected work showcasing front-end and full-stack development.</p>
        </header>

        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {projects.map((p) => (
            <Card key={p.title} className="hover:shadow-md transition-shadow animate-fade-in">
              <CardHeader>
                <CardTitle>{p.title}</CardTitle>
                <CardDescription>{p.desc}</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-2">
                  {p.stack.map((s) => (
                    <span key={s} className="rounded-md bg-secondary px-2 py-1 text-xs text-secondary-foreground">{s}</span>
                  ))}
                </div>
              </CardContent>
              <CardFooter>
                <Button asChild>
                  <a href={p.demo} target="_blank" rel="noreferrer">Live Demo</a>
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>
      </section>
    </>
  );
};

export default Projects;
