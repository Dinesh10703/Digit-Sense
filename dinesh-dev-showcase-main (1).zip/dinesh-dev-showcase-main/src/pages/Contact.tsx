import { Helmet } from "react-helmet-async";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";

const Contact = () => {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [message, setMessage] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const subject = encodeURIComponent(`Portfolio Contact from ${name}`);
    const body = encodeURIComponent(`Name: ${name}\nEmail: ${email}\n\n${message}`);
    window.location.href = `mailto:dineshborra121@gmail.com?subject=${subject}&body=${body}`;
  };

  return (
    <>
      <Helmet>
        <title>Contact | Dinesh Borra</title>
        <meta name="description" content="Get in touch with Dinesh Borra. Contact via form or email/phone." />
        <link rel="canonical" href={typeof window !== 'undefined' ? window.location.href : '/contact'} />
      </Helmet>

      <section className="container py-12">
        <header className="mb-6 text-center">
          <h1 className="font-display text-3xl font-bold md:text-4xl">Contact</h1>
          <p className="mt-2 text-muted-foreground">Let’s build something great together.</p>
        </header>

        <div className="mx-auto grid max-w-3xl gap-8 md:grid-cols-2">
          <form className="space-y-4" onSubmit={handleSubmit}>
            <div>
              <Label htmlFor="name">Name</Label>
              <Input id="name" value={name} onChange={(e) => setName(e.target.value)} required />
            </div>
            <div>
              <Label htmlFor="email">Email</Label>
              <Input id="email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
            </div>
            <div>
              <Label htmlFor="message">Message</Label>
              <Textarea id="message" rows={5} value={message} onChange={(e) => setMessage(e.target.value)} required />
            </div>
            <Button type="submit" variant="hero" className="w-full">Send Message</Button>
          </form>

          <aside className="rounded-lg border p-4">
            <h2 className="font-display text-xl font-semibold">Contact Details</h2>
            <p className="mt-2 text-muted-foreground">Email</p>
            <a className="story-link" href="mailto:dineshborra121@gmail.com">dineshborra121@gmail.com</a>
            <p className="mt-4 text-muted-foreground">Phone</p>
            <a className="story-link" href="tel:+919398396029">+91 9398396029</a>
          </aside>
        </div>
      </section>
    </>
  );
};

export default Contact;
