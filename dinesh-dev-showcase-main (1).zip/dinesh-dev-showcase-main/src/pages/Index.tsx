import { Helmet } from "react-helmet-async";
import { Button } from "@/components/ui/button";
import { SiGithub, SiLinkedin, SiMinutemailer } from "react-icons/si";
import { FiDownload } from "react-icons/fi";

const Index = () => {
  return (
    <>
      <Helmet>
        <title>Home | Dinesh Borra — Frontend Developer</title>
        <meta name="description" content="Frontend Developer & Full-Stack Enthusiast specializing in React.js, Node.js, MongoDB, and C++. Explore projects and get in touch." />
        <link rel="canonical" href={typeof window !== 'undefined' ? window.location.href : '/'} />
        <script type="application/ld+json">{JSON.stringify({
          "@context": "https://schema.org",
          "@type": "Person",
          name: "Dinesh Borra",
          jobTitle: "Frontend Developer & Full-Stack Enthusiast",
          url: typeof window !== 'undefined' ? window.location.origin : '',
          email: "mailto:dineshborra121@gmail.com",
          sameAs: [
            "https://github.com/",
            "https://www.linkedin.com/"
          ]
        })}</script>
      </Helmet>

      <section className="container flex min-h-[70vh] flex-col items-center justify-center gap-6 py-16 text-center animate-enter">
        <p className="text-sm uppercase tracking-wider text-muted-foreground">Hello, I am</p>
        <h1 className="font-display text-4xl font-bold leading-tight sm:text-5xl md:text-6xl">Dinesh Borra</h1>
        <p className="text-lg text-muted-foreground md:text-xl">Frontend Developer & Full-Stack Enthusiast</p>

        <p className="max-w-2xl text-balance text-muted-foreground">
          I build fast, delightful web apps with React.js, Node.js, MongoDB, and C++. Clean code, great UX, and solid architecture.
        </p>

        <div className="mt-4 flex flex-wrap items-center justify-center gap-3">
          <Button asChild variant="hero" className="hover-scale">
            <a href="/resume.pdf" download>
              <FiDownload /> Download Resume
            </a>
          </Button>
          <Button asChild variant="outline" className="hover-scale">
            <a href="https://github.com/" target="_blank" rel="noreferrer">
              <SiGithub /> GitHub
            </a>
          </Button>
          <Button asChild variant="outline" className="hover-scale">
            <a href="https://www.linkedin.com/" target="_blank" rel="noreferrer">
              <SiLinkedin /> LinkedIn
            </a>
          </Button>
          <Button asChild variant="outline" className="hover-scale">
            <a href="mailto:dineshborra121@gmail.com">
              <SiMinutemailer /> Email
            </a>
          </Button>
        </div>
      </section>
    </>
  );
};

export default Index;
