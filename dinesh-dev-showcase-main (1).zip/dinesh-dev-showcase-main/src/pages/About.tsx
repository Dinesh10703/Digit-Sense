import { Helmet } from "react-helmet-async";

const About = () => {
  return (
    <>
      <Helmet>
        <title>About | Dinesh Borra</title>
        <meta name="description" content="My journey as a developer, internship at Edunet (May–June 2024), and passion for building impactful software." />
        <link rel="canonical" href={typeof window !== 'undefined' ? window.location.href : '/about'} />
      </Helmet>

      <section className="container py-12">
        <header className="mb-6 text-center">
          <h1 className="font-display text-3xl font-bold md:text-4xl">About</h1>
          <p className="mt-2 text-muted-foreground">A brief story about my journey.</p>
        </header>

        <article className="mx-auto max-w-3xl space-y-4 text-lg leading-relaxed text-muted-foreground">
          <p>
            I’m Dinesh Borra, a Frontend Developer & Full-Stack Enthusiast who loves crafting fast, accessible, and beautiful web experiences.
            I focus on clean architecture, performance, and thoughtful UX.
          </p>
          <p>
            In May–June 2024, I completed an internship at Edunet where I contributed to building scalable web solutions and collaborated in an agile environment.
            The experience sharpened my skills in modern JavaScript tooling and best practices.
          </p>
          <p>
            Beyond work, I enjoy exploring algorithms and data structures, optimizing code, and learning new technologies. I aspire to build software that makes a real-world impact.
          </p>
        </article>
      </section>
    </>
  );
};

export default About;
