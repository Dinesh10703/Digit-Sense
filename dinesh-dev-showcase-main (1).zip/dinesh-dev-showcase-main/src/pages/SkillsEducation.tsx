import { Helmet } from "react-helmet-async";
import { SiC, SiCplusplus, SiPython, SiJavascript, SiHtml5, SiCss3, SiReact, SiNodedotjs, SiMongodb, SiExpress, SiMysql, SiLeetcode } from "react-icons/si";

const skills = [
  { name: "C", Icon: SiC },
  { name: "C++", Icon: SiCplusplus },
  { name: "Python", Icon: SiPython },
  { name: "JavaScript", Icon: SiJavascript },
  { name: "HTML", Icon: SiHtml5 },
  { name: "CSS", Icon: SiCss3 },
  { name: "React.js", Icon: SiReact },
  { name: "Node.js", Icon: SiNodedotjs },
  { name: "MongoDB", Icon: SiMongodb },
  { name: "Express.js", Icon: SiExpress },
  { name: "MySQL", Icon: SiMysql },
  { name: "DSA", Icon: SiLeetcode },
];

const SkillsEducation = () => {
  return (
    <>
      <Helmet>
        <title>Skills & Education | Dinesh Borra</title>
        <meta name="description" content="Skills in C, C++, Python, JavaScript, HTML, CSS, React, Node, MongoDB, Express, MySQL, and DSA. Education: B.Tech SRM University (2022–2026)." />
        <link rel="canonical" href={typeof window !== 'undefined' ? window.location.href : '/skills'} />
      </Helmet>

      <section className="container py-12">
        <header className="mb-8 text-center">
          <h1 className="font-display text-3xl font-bold md:text-4xl">Skills & Education</h1>
          <p className="mt-2 text-muted-foreground">A snapshot of my technical toolkit and academic background.</p>
        </header>

        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6">
          {skills.map(({ name, Icon }) => (
            <div key={name} className="group flex flex-col items-center justify-center rounded-lg border p-4 transition-colors hover:bg-accent">
              <Icon className="mb-2 h-8 w-8 text-primary group-hover:scale-105 transition-transform" aria-hidden />
              <span className="text-sm text-foreground">{name}</span>
            </div>
          ))}
        </div>

        <article className="mx-auto mt-12 max-w-3xl rounded-lg border bg-card p-6 shadow-sm">
          <h2 className="font-display text-2xl font-semibold">Education</h2>
          <p className="mt-2 text-muted-foreground">B.Tech, SRM University (2022–2026)</p>
          <p className="mt-1">CGPA: 8.17</p>
        </article>
      </section>
    </>
  );
};

export default SkillsEducation;
