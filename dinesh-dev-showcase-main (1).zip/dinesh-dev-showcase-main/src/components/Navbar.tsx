import { useState } from "react";
import { Link, NavLink } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { SiGithub, SiLinkedin } from "react-icons/si";

const navItems = [
  { to: "/", label: "Home" },
  { to: "/projects", label: "Projects" },
  { to: "/skills", label: "Skills & Education" },
  { to: "/about", label: "About" },
  { to: "/contact", label: "Contact" },
];

const Navbar = () => {
  const [open, setOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50 border-b bg-background/80 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <nav className="container flex h-16 items-center justify-between">
        <Link to="/" className="flex items-center gap-2 font-display text-lg">
          <span className="inline-flex h-8 w-8 items-center justify-center rounded-md bg-[var(--gradient-primary)] text-primary-foreground shadow-[var(--shadow-glow)]">DB</span>
          <span className="font-semibold">Dinesh Borra</span>
        </Link>

        <div className="hidden items-center gap-6 md:flex">
          {navItems.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              className={({ isActive }) =>
                `text-sm transition-colors story-link ${isActive ? "text-primary" : "text-muted-foreground hover:text-foreground"}`
              }
            >
              {item.label}
            </NavLink>
          ))}
          <div className="ml-4 flex items-center gap-2">
            <Button asChild variant="outline" size="sm">
              <a href="https://github.com/" target="_blank" rel="noreferrer" aria-label="GitHub">
                <SiGithub /> GitHub
              </a>
            </Button>
            <Button asChild variant="outline" size="sm">
              <a href="https://www.linkedin.com/" target="_blank" rel="noreferrer" aria-label="LinkedIn">
                <SiLinkedin /> LinkedIn
              </a>
            </Button>
          </div>
        </div>

        <div className="md:hidden">
          <Button variant="outline" size="icon" aria-label="Toggle menu" onClick={() => setOpen((o) => !o)}>
            <svg
              xmlns="http://www.w3.org/2000/svg"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              className="h-5 w-5"
            >
              <path d="M4 6h16M4 12h16M4 18h16" />
            </svg>
          </Button>
        </div>
      </nav>

      {open && (
        <div className="md:hidden animate-slide-in-right border-t bg-background">
          <div className="container flex flex-col gap-2 py-4">
            {navItems.map((item) => (
              <NavLink
                key={item.to}
                to={item.to}
                onClick={() => setOpen(false)}
                className={({ isActive }) =>
                  `py-2 text-sm ${isActive ? "text-primary" : "text-muted-foreground hover:text-foreground"}`
                }
              >
                {item.label}
              </NavLink>
            ))}
            <div className="mt-2 flex items-center gap-2">
              <Button asChild variant="outline" size="sm">
                <a href="https://github.com/" target="_blank" rel="noreferrer" aria-label="GitHub">
                  <SiGithub /> GitHub
                </a>
              </Button>
              <Button asChild variant="outline" size="sm">
                <a href="https://www.linkedin.com/" target="_blank" rel="noreferrer" aria-label="LinkedIn">
                  <SiLinkedin /> LinkedIn
                </a>
              </Button>
            </div>
          </div>
        </div>
      )}
    </header>
  );
};

export default Navbar;
