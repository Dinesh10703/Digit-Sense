const Footer = () => {
  return (
    <footer className="border-t">
      <div className="container py-6 text-center text-sm text-muted-foreground">
        © {new Date().getFullYear()} Dinesh Borra. All rights reserved.
      </div>
    </footer>
  );
};

export default Footer;
